<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appDevDebugProjectContainerUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($rawPathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($rawPathinfo);
        $trimmedPathinfo = rtrim($pathinfo, '/');
        $context = $this->context;
        $request = $this->request ?: $this->createRequest($pathinfo);
        $requestMethod = $canonicalMethod = $context->getMethod();

        if ('HEAD' === $requestMethod) {
            $canonicalMethod = 'GET';
        }

        if (0 === strpos($pathinfo, '/_')) {
            // _wdt
            if (0 === strpos($pathinfo, '/_wdt') && preg_match('#^/_wdt/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_wdt')), array (  '_controller' => 'web_profiler.controller.profiler:toolbarAction',));
            }

            if (0 === strpos($pathinfo, '/_profiler')) {
                // _profiler_home
                if ('/_profiler' === $trimmedPathinfo) {
                    $ret = array (  '_controller' => 'web_profiler.controller.profiler:homeAction',  '_route' => '_profiler_home',);
                    if ('/' === substr($pathinfo, -1)) {
                        // no-op
                    } elseif ('GET' !== $canonicalMethod) {
                        goto not__profiler_home;
                    } else {
                        return array_replace($ret, $this->redirect($rawPathinfo.'/', '_profiler_home'));
                    }

                    return $ret;
                }
                not__profiler_home:

                if (0 === strpos($pathinfo, '/_profiler/search')) {
                    // _profiler_search
                    if ('/_profiler/search' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchAction',  '_route' => '_profiler_search',);
                    }

                    // _profiler_search_bar
                    if ('/_profiler/search_bar' === $pathinfo) {
                        return array (  '_controller' => 'web_profiler.controller.profiler:searchBarAction',  '_route' => '_profiler_search_bar',);
                    }

                }

                // _profiler_phpinfo
                if ('/_profiler/phpinfo' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:phpinfoAction',  '_route' => '_profiler_phpinfo',);
                }

                // _profiler_search_results
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/search/results$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_search_results')), array (  '_controller' => 'web_profiler.controller.profiler:searchResultsAction',));
                }

                // _profiler_open_file
                if ('/_profiler/open' === $pathinfo) {
                    return array (  '_controller' => 'web_profiler.controller.profiler:openAction',  '_route' => '_profiler_open_file',);
                }

                // _profiler
                if (preg_match('#^/_profiler/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler')), array (  '_controller' => 'web_profiler.controller.profiler:panelAction',));
                }

                // _profiler_router
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/router$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_router')), array (  '_controller' => 'web_profiler.controller.router:panelAction',));
                }

                // _profiler_exception
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception')), array (  '_controller' => 'web_profiler.controller.exception:showAction',));
                }

                // _profiler_exception_css
                if (preg_match('#^/_profiler/(?P<token>[^/]++)/exception\\.css$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_profiler_exception_css')), array (  '_controller' => 'web_profiler.controller.exception:cssAction',));
                }

            }

            // _twig_error_test
            if (0 === strpos($pathinfo, '/_error') && preg_match('#^/_error/(?P<code>\\d+)(?:\\.(?P<_format>[^/]++))?$#sD', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_twig_error_test')), array (  '_controller' => 'twig.controller.preview_error:previewErrorPageAction',  '_format' => 'html',));
            }

        }

        // fos_user_security_login
        if ('/admin' === $pathinfo) {
            $ret = array (  '_controller' => 'fos_user.security.controller:loginAction',  '_route' => 'fos_user_security_login',);
            if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                $allow = array_merge($allow, array('GET', 'POST'));
                goto not_fos_user_security_login;
            }

            return $ret;
        }
        not_fos_user_security_login:

        if (0 === strpos($pathinfo, '/api')) {
            if (0 === strpos($pathinfo, '/api/CheckMaster')) {
                // app_apirest_apirestcheckmaster_wama
                if ('/api/CheckMaster' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::wamaAction',  '_route' => 'app_apirest_apirestcheckmaster_wama',);
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_apirest_apirestcheckmaster_wama;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_wama:

                // app_apirest_apirestcheckmaster_wamaid
                if (preg_match('#^/api/CheckMaster/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'app_apirest_apirestcheckmaster_wamaid')), array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::wamaIdAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_apirest_apirestcheckmaster_wamaid;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_wamaid:

                // app_apirest_apirestcheckmaster_save
                if ('/api/CheckMaster' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::saveAction',  '_route' => 'app_apirest_apirestcheckmaster_save',);
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_apirest_apirestcheckmaster_save;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_save:

                // app_apirest_apirestcheckmaster_checkmailmaster
                if ('/api/CheckMaster' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::checkMailMasterAction',  '_route' => 'app_apirest_apirestcheckmaster_checkmailmaster',);
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_apirest_apirestcheckmaster_checkmailmaster;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_checkmailmaster:

            }

            elseif (0 === strpos($pathinfo, '/api/CheckCodeValidation')) {
                // app_apirest_apirestcheckmaster_checkcodevalidation
                if ('/api/CheckCodeValidation' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::CheckCodeValidationAction',  '_route' => 'app_apirest_apirestcheckmaster_checkcodevalidation',);
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_apirest_apirestcheckmaster_checkcodevalidation;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_checkcodevalidation:

                // app_apirest_apirestcheckmaster_checkcodevalidationresetpassword
                if ('/api/CheckCodeValidationResetPassword' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::CheckCodeValidationResetPasswordAction',  '_route' => 'app_apirest_apirestcheckmaster_checkcodevalidationresetpassword',);
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_apirest_apirestcheckmaster_checkcodevalidationresetpassword;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_checkcodevalidationresetpassword:

                // app_apirest_apirestcheckmaster_checkcodevalidationunlockuser
                if ('/api/CheckCodeValidationUnlockUser' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::CheckCodeValidationUnlockUserAction',  '_route' => 'app_apirest_apirestcheckmaster_checkcodevalidationunlockuser',);
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_apirest_apirestcheckmaster_checkcodevalidationunlockuser;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_checkcodevalidationunlockuser:

            }

            elseif (0 === strpos($pathinfo, '/api/Re')) {
                // app_apirest_apirestcheckmaster_registerusermaster
                if ('/api/RegisterUserMaster' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::registerUserMasterAction',  '_route' => 'app_apirest_apirestcheckmaster_registerusermaster',);
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_apirest_apirestcheckmaster_registerusermaster;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_registerusermaster:

                // app_apirest_apirestcheckmaster_resetpassword
                if ('/api/ResetPassword' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::ResetPasswordAction',  '_route' => 'app_apirest_apirestcheckmaster_resetpassword',);
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_apirest_apirestcheckmaster_resetpassword;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_resetpassword:

                // app_apirest_apirestcheckmaster_requestcodeunlockuser
                if ('/api/RequestCodeUnlockUser' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::RequestCodeUnlockUserAction',  '_route' => 'app_apirest_apirestcheckmaster_requestcodeunlockuser',);
                    if (!in_array($requestMethod, array('PUT'))) {
                        $allow = array_merge($allow, array('PUT'));
                        goto not_app_apirest_apirestcheckmaster_requestcodeunlockuser;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_requestcodeunlockuser:

            }

            elseif (0 === strpos($pathinfo, '/api/login')) {
                // app_apirest_apirestcheckmaster_apilogin
                if ('/api/login' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::apiLoginAction',  '_route' => 'app_apirest_apirestcheckmaster_apilogin',);
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_app_apirest_apirestcheckmaster_apilogin;
                    }

                    return $ret;
                }
                not_app_apirest_apirestcheckmaster_apilogin:

                // api_login_check
                if ('/api/login_check' === $pathinfo) {
                    return array('_route' => 'api_login_check');
                }

            }

            // app_apirest_apirestcheckmaster_requestcoderecoverpassword
            if ('/api/requestCodeRecoverPassword' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::requestCodeRecoverPasswordAction',  '_route' => 'app_apirest_apirestcheckmaster_requestcoderecoverpassword',);
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_apirest_apirestcheckmaster_requestcoderecoverpassword;
                }

                return $ret;
            }
            not_app_apirest_apirestcheckmaster_requestcoderecoverpassword:

            // app_apirest_apirestcheckmaster_loadselects
            if ('/api/LoadSelects' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::LoadSelectsAction',  '_route' => 'app_apirest_apirestcheckmaster_loadselects',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_apirest_apirestcheckmaster_loadselects;
                }

                return $ret;
            }
            not_app_apirest_apirestcheckmaster_loadselects:

            // app_apirest_apirestcheckmaster_blockuser
            if ('/api/BlockUser' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::BlockUserAction',  '_route' => 'app_apirest_apirestcheckmaster_blockuser',);
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_apirest_apirestcheckmaster_blockuser;
                }

                return $ret;
            }
            not_app_apirest_apirestcheckmaster_blockuser:

            // app_apirest_apirestcheckmaster_unlockuser
            if ('/api/UnlockUser' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCheckMaster::UnlockUserAction',  '_route' => 'app_apirest_apirestcheckmaster_unlockuser',);
                if (!in_array($requestMethod, array('PUT'))) {
                    $allow = array_merge($allow, array('PUT'));
                    goto not_app_apirest_apirestcheckmaster_unlockuser;
                }

                return $ret;
            }
            not_app_apirest_apirestcheckmaster_unlockuser:

            // app_apirest_apirestcountry_get
            if ('/apiCountry' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestCountryController::getAction',  '_route' => 'app_apirest_apirestcountry_get',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_app_apirest_apirestcountry_get;
                }

                return $ret;
            }
            not_app_apirest_apirestcountry_get:

            if (0 === strpos($pathinfo, '/apiusersfront')) {
                // app_apirest_apirestusersfront_get
                if ('/apiusersfront' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestUsersFrontController::getAction',  '_route' => 'app_apirest_apirestusersfront_get',);
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_app_apirest_apirestusersfront_get;
                    }

                    return $ret;
                }
                not_app_apirest_apirestusersfront_get:

                // get
                if (0 === strpos($pathinfo, '/apiusersfront/apiusersfront') && preg_match('#^/apiusersfront/apiusersfront(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'get')), array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestUsersFrontController:getAction',  '_format' => NULL,));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_get;
                    }

                    return $ret;
                }
                not_get:

            }

            // api_users_get_users
            if (0 === strpos($pathinfo, '/api/users') && preg_match('#^/api/users(?:\\.(?P<_format>json|html))?$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'api_users_get_users')), array (  '_controller' => 'AppBundle\\Controller\\UsersController:getUsersAction',  '_format' => NULL,));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_api_users_get_users;
                }

                return $ret;
            }
            not_api_users_get_users:

        }

        elseif (0 === strpos($pathinfo, '/l')) {
            if (0 === strpos($pathinfo, '/login')) {
                // fos_user_security_check
                if ('/login_check' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.security.controller:checkAction',  '_route' => 'fos_user_security_check',);
                    if (!in_array($requestMethod, array('POST'))) {
                        $allow = array_merge($allow, array('POST'));
                        goto not_fos_user_security_check;
                    }

                    return $ret;
                }
                not_fos_user_security_check:

                // login
                if (preg_match('#^/login/(?P<email>[^/]++)/(?P<pass>[^/]++)$#sD', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'login')), array (  '_controller' => 'AppBundle\\Controller\\ApiRest\\ApiRestLogin::loginAction',));
                }

            }

            // fos_user_security_logout
            if ('/logout' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.security.controller:logoutAction',  '_route' => 'fos_user_security_logout',);
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_security_logout;
                }

                return $ret;
            }
            not_fos_user_security_logout:

            if (0 === strpos($pathinfo, '/license')) {
                // license_list
                if ('/license/index' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\LicenseController::listAction',  '_route' => 'license_list',);
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_license_list;
                    }

                    return $ret;
                }
                not_license_list:

                // license_create
                if ('/license/create' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\LicenseController::createAction',  '_route' => 'license_create',);
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_license_create;
                    }

                    return $ret;
                }
                not_license_create:

                // license_edit
                if (0 === strpos($pathinfo, '/license/edit') && preg_match('#^/license/edit/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'license_edit')), array (  '_controller' => 'AppBundle\\Controller\\LicenseController::editAction',));
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_license_edit;
                    }

                    return $ret;
                }
                not_license_edit:

                // license_details
                if (0 === strpos($pathinfo, '/license/details') && preg_match('#^/license/details/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'license_details')), array (  '_controller' => 'AppBundle\\Controller\\LicenseController::detailsAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_license_details;
                    }

                    return $ret;
                }
                not_license_details:

                // license_delete
                if (0 === strpos($pathinfo, '/license/delete') && preg_match('#^/license/delete/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'license_delete')), array (  '_controller' => 'AppBundle\\Controller\\LicenseController::deleteAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_license_delete;
                    }

                    return $ret;
                }
                not_license_delete:

            }

        }

        elseif (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if ('/profile' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'fos_user.profile.controller:showAction',  '_route' => 'fos_user_profile_show',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_fos_user_profile_show;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'fos_user_profile_show'));
                }

                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_fos_user_profile_show;
                }

                return $ret;
            }
            not_fos_user_profile_show:

            // fos_user_profile_edit
            if ('/profile/edit' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.profile.controller:editAction',  '_route' => 'fos_user_profile_edit',);
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_profile_edit;
                }

                return $ret;
            }
            not_fos_user_profile_edit:

            // fos_user_change_password
            if ('/profile/change-password' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.change_password.controller:changePasswordAction',  '_route' => 'fos_user_change_password',);
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_change_password;
                }

                return $ret;
            }
            not_fos_user_change_password:

        }

        elseif (0 === strpos($pathinfo, '/province')) {
            // province_list
            if ('/province/index' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ProvinceController::listAction',  '_route' => 'province_list',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_province_list;
                }

                return $ret;
            }
            not_province_list:

            // province_create
            if ('/province/create' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ProvinceController::createAction',  '_route' => 'province_create',);
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_province_create;
                }

                return $ret;
            }
            not_province_create:

            // province_edit
            if (0 === strpos($pathinfo, '/province/edit') && preg_match('#^/province/edit/(?P<id>[^/]++)/(?P<posicionProvince>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'province_edit')), array (  '_controller' => 'AppBundle\\Controller\\ProvinceController::editAction',));
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_province_edit;
                }

                return $ret;
            }
            not_province_edit:

            // province_details
            if (0 === strpos($pathinfo, '/province/details') && preg_match('#^/province/details/(?P<id>[^/]++)/(?P<posicionProvince>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'province_details')), array (  '_controller' => 'AppBundle\\Controller\\ProvinceController::detailsAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_province_details;
                }

                return $ret;
            }
            not_province_details:

            // province_delete
            if (0 === strpos($pathinfo, '/province/delete') && preg_match('#^/province/delete/(?P<id>[^/]++)/(?P<posicionProvince>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'province_delete')), array (  '_controller' => 'AppBundle\\Controller\\ProvinceController::deleteAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_province_delete;
                }

                return $ret;
            }
            not_province_delete:

        }

        elseif (0 === strpos($pathinfo, '/register')) {
            // fos_user_registration_register
            if ('/register' === $trimmedPathinfo) {
                $ret = array (  '_controller' => 'fos_user.registration.controller:registerAction',  '_route' => 'fos_user_registration_register',);
                if ('/' === substr($pathinfo, -1)) {
                    // no-op
                } elseif ('GET' !== $canonicalMethod) {
                    goto not_fos_user_registration_register;
                } else {
                    return array_replace($ret, $this->redirect($rawPathinfo.'/', 'fos_user_registration_register'));
                }

                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_registration_register;
                }

                return $ret;
            }
            not_fos_user_registration_register:

            // fos_user_registration_check_email
            if ('/register/check-email' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.registration.controller:checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_fos_user_registration_check_email;
                }

                return $ret;
            }
            not_fos_user_registration_check_email:

            if (0 === strpos($pathinfo, '/register/confirm')) {
                // fos_user_registration_confirm
                if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'fos_user.registration.controller:confirmAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_fos_user_registration_confirm;
                    }

                    return $ret;
                }
                not_fos_user_registration_confirm:

                // fos_user_registration_confirmed
                if ('/register/confirmed' === $pathinfo) {
                    $ret = array (  '_controller' => 'fos_user.registration.controller:confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_fos_user_registration_confirmed;
                    }

                    return $ret;
                }
                not_fos_user_registration_confirmed:

            }

        }

        elseif (0 === strpos($pathinfo, '/resetting')) {
            // fos_user_resetting_request
            if ('/resetting/request' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.resetting.controller:requestAction',  '_route' => 'fos_user_resetting_request',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_fos_user_resetting_request;
                }

                return $ret;
            }
            not_fos_user_resetting_request:

            // fos_user_resetting_reset
            if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'fos_user.resetting.controller:resetAction',));
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_fos_user_resetting_reset;
                }

                return $ret;
            }
            not_fos_user_resetting_reset:

            // fos_user_resetting_send_email
            if ('/resetting/send-email' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.resetting.controller:sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                if (!in_array($requestMethod, array('POST'))) {
                    $allow = array_merge($allow, array('POST'));
                    goto not_fos_user_resetting_send_email;
                }

                return $ret;
            }
            not_fos_user_resetting_send_email:

            // fos_user_resetting_check_email
            if ('/resetting/check-email' === $pathinfo) {
                $ret = array (  '_controller' => 'fos_user.resetting.controller:checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_fos_user_resetting_check_email;
                }

                return $ret;
            }
            not_fos_user_resetting_check_email:

        }

        elseif (0 === strpos($pathinfo, '/country')) {
            // country_list
            if ('/country/index' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\CountryController::listAction',  '_route' => 'country_list',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_country_list;
                }

                return $ret;
            }
            not_country_list:

            // country_create
            if ('/country/create' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\CountryController::createAction',  '_route' => 'country_create',);
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_country_create;
                }

                return $ret;
            }
            not_country_create:

            // country_edit
            if (0 === strpos($pathinfo, '/country/edit') && preg_match('#^/country/edit/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'country_edit')), array (  '_controller' => 'AppBundle\\Controller\\CountryController::editAction',));
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_country_edit;
                }

                return $ret;
            }
            not_country_edit:

            // country_details
            if (0 === strpos($pathinfo, '/country/details') && preg_match('#^/country/details/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'country_details')), array (  '_controller' => 'AppBundle\\Controller\\CountryController::detailsAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_country_details;
                }

                return $ret;
            }
            not_country_details:

            // country_delete
            if (0 === strpos($pathinfo, '/country/delete') && preg_match('#^/country/delete/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'country_delete')), array (  '_controller' => 'AppBundle\\Controller\\CountryController::deleteAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_country_delete;
                }

                return $ret;
            }
            not_country_delete:

        }

        // homepage
        if ('' === $trimmedPathinfo) {
            $ret = array (  '_controller' => 'AppBundle\\Controller\\DefaultController::indexAction',  '_route' => 'homepage',);
            if ('/' === substr($pathinfo, -1)) {
                // no-op
            } elseif ('GET' !== $canonicalMethod) {
                goto not_homepage;
            } else {
                return array_replace($ret, $this->redirect($rawPathinfo.'/', 'homepage'));
            }

            return $ret;
        }
        not_homepage:

        if (0 === strpos($pathinfo, '/exams')) {
            // exams_list
            if ('/exams/index' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ExamsController::listAction',  '_route' => 'exams_list',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_exams_list;
                }

                return $ret;
            }
            not_exams_list:

            // exams_create
            if ('/exams/create' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\ExamsController::createAction',  '_route' => 'exams_create',);
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_exams_create;
                }

                return $ret;
            }
            not_exams_create:

            // exams_edit
            if (0 === strpos($pathinfo, '/exams/edit') && preg_match('#^/exams/edit/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'exams_edit')), array (  '_controller' => 'AppBundle\\Controller\\ExamsController::editAction',));
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_exams_edit;
                }

                return $ret;
            }
            not_exams_edit:

            // exams_details
            if (0 === strpos($pathinfo, '/exams/details') && preg_match('#^/exams/details/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'exams_details')), array (  '_controller' => 'AppBundle\\Controller\\ExamsController::detailsAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_exams_details;
                }

                return $ret;
            }
            not_exams_details:

            // exams_delete
            if (0 === strpos($pathinfo, '/exams/delete') && preg_match('#^/exams/delete/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'exams_delete')), array (  '_controller' => 'AppBundle\\Controller\\ExamsController::deleteAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_exams_delete;
                }

                return $ret;
            }
            not_exams_delete:

        }

        elseif (0 === strpos($pathinfo, '/medical_center')) {
            // medical_center_list
            if ('/medical_center/index' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::listAction',  '_route' => 'medical_center_list',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_medical_center_list;
                }

                return $ret;
            }
            not_medical_center_list:

            // images
            if ('/medical_center/images' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::LoadImages',  '_route' => 'images',);
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_images;
                }

                return $ret;
            }
            not_images:

            // medical_center_create
            if ('/medical_center/create' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::createAction',  '_route' => 'medical_center_create',);
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_medical_center_create;
                }

                return $ret;
            }
            not_medical_center_create:

            // medical_center_edit
            if (0 === strpos($pathinfo, '/medical_center/edit') && preg_match('#^/medical_center/edit/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'medical_center_edit')), array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::editAction',));
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_medical_center_edit;
                }

                return $ret;
            }
            not_medical_center_edit:

            // medical_center_details
            if (0 === strpos($pathinfo, '/medical_center/details') && preg_match('#^/medical_center/details/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'medical_center_details')), array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::detailsAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_medical_center_details;
                }

                return $ret;
            }
            not_medical_center_details:

            if (0 === strpos($pathinfo, '/medical_center/delete')) {
                // medical_center_delete
                if (preg_match('#^/medical_center/delete/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                    $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'medical_center_delete')), array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::deleteAction',));
                    if (!in_array($canonicalMethod, array('GET'))) {
                        $allow = array_merge($allow, array('GET'));
                        goto not_medical_center_delete;
                    }

                    return $ret;
                }
                not_medical_center_delete:

                // deletebranchofficess
                if ('/medical_center/deletebranchofficess' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::deleteBranchOfficess',  '_route' => 'deletebranchofficess',);
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_deletebranchofficess;
                    }

                    return $ret;
                }
                not_deletebranchofficess:

                // deletelicense
                if ('/medical_center/deletelicense' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::deleteLicense',  '_route' => 'deletelicense',);
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_deletelicense;
                    }

                    return $ret;
                }
                not_deletelicense:

                // deletepayment
                if ('/medical_center/deletepayment' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::deletePayment',  '_route' => 'deletepayment',);
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_deletepayment;
                    }

                    return $ret;
                }
                not_deletepayment:

            }

            elseif (0 === strpos($pathinfo, '/medical_center/ajax')) {
                // ajax
                if ('/medical_center/ajax' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::LoadProvince',  '_route' => 'ajax',);
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_ajax;
                    }

                    return $ret;
                }
                not_ajax:

                // ajax_
                if ('/medical_center/ajax_' === $pathinfo) {
                    $ret = array (  '_controller' => 'AppBundle\\Controller\\MedicalCenterController::LoadLicenses',  '_route' => 'ajax_',);
                    if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                        $allow = array_merge($allow, array('GET', 'POST'));
                        goto not_ajax_;
                    }

                    return $ret;
                }
                not_ajax_:

            }

        }

        elseif (0 === strpos($pathinfo, '/users')) {
            // users_list
            if ('/users/index' === $pathinfo) {
                $ret = array (  '_controller' => 'AppBundle\\Controller\\UserController::listAction',  '_route' => 'users_list',);
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_users_list;
                }

                return $ret;
            }
            not_users_list:

            // profile_edit
            if (0 === strpos($pathinfo, '/users/edit-profile') && preg_match('#^/users/edit\\-profile/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'profile_edit')), array (  '_controller' => 'AppBundle\\Controller\\UserController::editProfileAction',));
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_profile_edit;
                }

                return $ret;
            }
            not_profile_edit:

            // change_password_edit
            if (0 === strpos($pathinfo, '/users/change-password') && preg_match('#^/users/change\\-password/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'change_password_edit')), array (  '_controller' => 'AppBundle\\Controller\\UserController::changePasswordAction',));
                if (!in_array($canonicalMethod, array('GET', 'POST'))) {
                    $allow = array_merge($allow, array('GET', 'POST'));
                    goto not_change_password_edit;
                }

                return $ret;
            }
            not_change_password_edit:

            // delete_user
            if (0 === strpos($pathinfo, '/users/delete-user') && preg_match('#^/users/delete\\-user/(?P<id>[^/]++)$#sD', $pathinfo, $matches)) {
                $ret = $this->mergeDefaults(array_replace($matches, array('_route' => 'delete_user')), array (  '_controller' => 'AppBundle\\Controller\\UserController::deleteAction',));
                if (!in_array($canonicalMethod, array('GET'))) {
                    $allow = array_merge($allow, array('GET'));
                    goto not_delete_user;
                }

                return $ret;
            }
            not_delete_user:

        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
